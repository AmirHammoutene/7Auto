This application makes some actions and movements automatic in the game 7 Days to Die.

Easy Anti-Cheat (EAC) have to be disable in order to use this software

Under GNU GENERAL PUBLIC LICENSE Version 3, 29 June 2007
----------
- First configure your ingame key settings needed for this program to simulate the correct keys
- Configure the Windows Shortcut you need to execute an automovement with this program in background, 7 Days to Die running in foreground
- Customize an automovement, you can save unlimited presets
- When playing to 7 Days to Die (EAC disabled), press the assigned shorcut to execute an automovement, press again to disable.
----------
Conceived and developed by Amir Hammoutene (amir.hammoutene@gmail.com) in October 2022.
Language of programmation and tools : C++, Qt Creator
Uses the qxtGlobalShorcut library (please read lib/authors)